---
name: submit-project
description: Use when the user asks to 提交项目 / 提交代码 / 上传项目 / 上传文件到 Gitee / commit 并 push。上传前必须先向用户获取目标仓库网址和要上传的文件位置，然后提交并推送到该 Gitee 仓库。
---

# 上传文件/项目到 Gitee

把本地指定位置的文件（或项目）用 git 提交并推送到**用户指定的** Gitee 仓库。

## 触发场景

用户说「提交项目」「提交代码」「上传到 gitee」「上传文件」「帮我 push」等，
需要把某些本地内容上传到 Gitee 仓库时使用本 skill。

## 必须先获取的两个输入

执行前必须拿到以下两项信息。**若用户未提供，先向用户询问，得到答复后再继续，不要自行猜测或使用默认值。**

1. **目标仓库网址**：要上传到的 Gitee 仓库地址。
   - 例：`https://gitee.com/Zhang_yao_fu/advanced-web-design.git`
   - 用户可能只给网页地址（不带 `.git`），推送时补上 `.git` 即可。
2. **文件位置**：要上传的本地文件或目录的绝对路径。
   - 例：`C:\Users\64020\OneDrive\Desktop\学工\qianduan`
   - 可以是单个文件，也可以是整个目录。

两项都拿到后，向用户复述一次「将把 `[文件位置]` 推送到 `[网址]`」，确认无误再执行。

## 执行步骤

1. **确定工作目录**
   - 若「文件位置」是**文件**，使用其所在目录；若是**目录**，直接使用该目录。
   - 后续所有 `git` 命令都用 `-C "<该目录>"` 指定。

2. **确认/初始化 git 仓库**
   - 运行 `git -C "<目录>" rev-parse --is-inside-work-tree`。
   - 若返回 `true`，说明已在某个仓库中，直接用该仓库。
   - 若不是仓库：先 `git -C "<目录>" init`，并确保存在 `.gitignore`（至少忽略 `node_modules/`、`dist/`、`build/`、`.env` 等）。

3. **查看变更**
   - 运行 `git -C "<目录>" status` 与 `git -C "<目录>" diff --stat`，确认要提交的内容。
   - 不要提交密钥、令牌、`.env` 等敏感文件。发现敏感文件时先中止并告知用户。
   - 若用户只想上传「文件位置」指向的单个文件，就只 `git add "<该文件>"`，不要 `add -A` 整个目录。

4. **同步更新 index.html（目录提交且存在 index.html 时）**
   - 若目录下存在 `index.html`，且其中包含卡片式页面导航（`<div class="card-grid">`），先扫描目录下所有 `.html` 文件。
   - 对比 index.html 中已有的 `href`，找出未被收录的页面（`index.html` 自身除外）。
   - 按现有卡片的相同结构，为每个新页面在 `.card-grid` 末尾追加一个 `<a class="card" href="文件名">` 卡片：
     - `.card-num`：两位数字序号，顺延现有最大编号（如 23、24）；
     - `.card-title`：页面功能名称；
     - `.card-desc`：`文件名 — 简要功能说明`；
     - 其余结构与样式类名保持与现有卡片一致。
   - 将更新后的 index.html 一并纳入本次提交。
   - 单文件提交，或目录中没有 index.html / 没有新页面时，跳过本步。

5. **暂存并提交**
   - 目录：`git -C "<目录>" add -A`
   - 单文件：`git -C "<目录>" add "<文件绝对路径>"`
   - 提交信息用简洁的祈使句，例如 `git commit -m "add submit-project skill"`。
   - 若无改动（nothing to commit），跳到第 7 步直接推送。

6. **确保远程指向用户提供的仓库**
   - 运行 `git -C "<目录>" remote -v`。
   - 若无 `origin`：`git -C "<目录>" remote add origin "<网址>"`
   - 若 `origin` 不是该地址：`git -C "<目录>" remote set-url origin "<网址>"`
   - `<网址>` 用用户提供的那一项。

7. **推送**
   - 首次推送当前分支：`git -C "<目录>" push -u origin HEAD`
   - 之后：`git -C "<目录>" push`
   - 若远端有新提交导致被拒绝：先 `git -C "<目录>" pull --rebase origin <branch>` 再 push；遇到冲突时告知用户手动解决，**不要强推**。
   - **不要**使用 `--force`，除非用户明确要求。

8. **汇报结果**
   - 用一句话说明：提交的 commit、推送的分支、以及用户提供的仓库网址。

## 注意

- 只在用户明确要求「提交/推送/上传」时才执行，不要主动提交。
- 每次执行都以用户本次提供的「网址 + 文件位置」为准，不要沿用上一次的地址或路径。
- 提交前不要修改用户的 git 全局配置。
- 认证失败（需要 Gitee 账号密码/令牌）时，提示用户配置凭据后重试。
